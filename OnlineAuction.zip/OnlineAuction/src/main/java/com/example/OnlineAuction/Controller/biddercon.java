package auction.demo.controller;

import auction.demo.model.bidder;

public interface biddercon {
    public bidder savebidder(bidder bidder1);
}
