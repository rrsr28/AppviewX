package com.example.OnlineAuction.Auction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuctionService
{

    @Autowired
    private AuctionRepository auctionRepository;

    // Service methods
}