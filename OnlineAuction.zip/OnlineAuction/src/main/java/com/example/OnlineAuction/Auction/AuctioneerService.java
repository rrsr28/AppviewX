package com.example.OnlineAuction.Auction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuctioneerService
{

    @Autowired
    private AuctioneerRepository auctioneerRepository;

    // Service methods
}